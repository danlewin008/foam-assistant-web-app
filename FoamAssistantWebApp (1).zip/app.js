
const e = React.createElement;

function BlanketThicknessCalculator() {
  const [fireType, setFireType] = React.useState('Class B');
  const [temperature, setTemperature] = React.useState(600);

  const getRecommendation = () => {
    if (fireType === 'Class A') {
      return temperature > 500 ? 'Use 0.8 mm fiberglass' : 'Use 0.6 mm fiberglass';
    } else if (fireType === 'Class B') {
      return temperature > 600 ? 'Use 1.0 mm Kevlar-coated' : 'Use 0.8 mm Kevlar-coated';
    } else if (fireType === 'Class F') {
      return temperature > 400 ? 'Use 1.2 mm fiberglass' : 'Use 1.0 mm fiberglass';
    }
    return 'Select valid fire type';
  };

  return e('div', null,
    e('h2', null, 'Blanket Thickness Calculator'),
    e('label', null, 'Fire Type:'),
    e('select', { value: fireType, onChange: e => setFireType(e.target.value) },
      ['Class A', 'Class B', 'Class F'].map(ft => e('option', { value: ft }, ft))
    ),
    e('label', null, `Temperature (°C): ${temperature}`),
    e('input', {
      type: 'range', min: 100, max: 1000, step: 50,
      value: temperature,
      onChange: e => setTemperature(Number(e.target.value))
    }),
    e('p', null, `Recommended Thickness: ${getRecommendation()}`)
  );
}

function BlanketAreaCalculator() {
  const [diameter, setDiameter] = React.useState(0.5);
  const fireArea = Math.PI * Math.pow(diameter / 2, 2);
  const recommendedArea = fireArea * 1.2;

  return e('div', null,
    e('h2', null, 'Blanket Area Calculator'),
    e('label', null, `Fire Surface Diameter (m): ${diameter.toFixed(1)}`),
    e('input', {
      type: 'range', min: 0.1, max: 2.0, step: 0.1,
      value: diameter,
      onChange: e => setDiameter(Number(e.target.value))
    }),
    e('p', null, `Fire Area: ${fireArea.toFixed(2)} m²`),
    e('p', null, `Recommended Blanket Area: ${recommendedArea.toFixed(2)} m²`)
  );
}

function InductorBranchCalculator() {
  const [ind225, setInd225] = React.useState(0);
  const [ind450, setInd450] = React.useState(1);
  const [br225, setBr225] = React.useState(0);
  const [br450, setBr450] = React.useState(1);

  const totalFlow = (ind225 + br225) * 225 + (ind450 + br450) * 450;

  return e('div', null,
    e('h2', null, 'Inductor & Branch Flow Calculator'),
    e('label', null, `Inductors @ 225 L/min: ${ind225}`),
    e('input', {
      type: 'range', min: 0, max: 10,
      value: ind225,
      onChange: e => setInd225(Number(e.target.value))
    }),
    e('label', null, `Inductors @ 450 L/min: ${ind450}`),
    e('input', {
      type: 'range', min: 0, max: 10,
      value: ind450,
      onChange: e => setInd450(Number(e.target.value))
    }),
    e('label', null, `Branches @ 225 L/min: ${br225}`),
    e('input', {
      type: 'range', min: 0, max: 10,
      value: br225,
      onChange: e => setBr225(Number(e.target.value))
    }),
    e('label', null, `Branches @ 450 L/min: ${br450}`),
    e('input', {
      type: 'range', min: 0, max: 10,
      value: br450,
      onChange: e => setBr450(Number(e.target.value))
    }),
    e('p', null, `Total Flow Rate: ${totalFlow} L/min`)
  );
}

function App() {
  return e('div', null,
    e('h1', null, 'Foam Assistant Web App'),
    e(BlanketThicknessCalculator),
    e(BlanketAreaCalculator),
    e(InductorBranchCalculator)
  );
}

ReactDOM.render(e(App), document.getElementById('root'));
